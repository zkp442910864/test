<template>
    <div>
        HomeFirends
    </div>
</template>

<script>
    export default {
        name: 'HomeFirends',
        data() {
            return {};
        },
        created() {

        },
        mounted() {

        },
        watch: {},
        methods: {},
        computed: {},
        components: {}
    };
</script>

<style scoped>

</style>
