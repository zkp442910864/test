<template>
    <div>
        HomeVideo
    </div>
</template>

<script>
    export default {
        name: 'HomeVideo',
        data() {
            return {};
        },
        created() {

        },
        mounted() {

        },
        watch: {},
        methods: {},
        computed: {},
        components: {}
    };
</script>

<style scoped>

</style>
