<template>
    <div>
        HomeAccount
    </div>
</template>

<script>
    export default {
        name: 'HomeAccount',
        data() {
            return {};
        },
        created() {

        },
        mounted() {

        },
        watch: {},
        methods: {},
        computed: {},
        components: {}
    };
</script>

<style scoped>

</style>
