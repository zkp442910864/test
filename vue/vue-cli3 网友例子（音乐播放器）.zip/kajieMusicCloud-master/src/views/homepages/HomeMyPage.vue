<template>
    <div>
        HomeMyPage
    </div>
</template>

<script>
    export default {
        name: 'HomeMyPage',
        data() {
            return {};
        },
        created() {

        },
        mounted() {

        },
        watch: {},
        methods: {},
        computed: {},
        components: {}
    };
</script>

<style scoped>

</style>
