<template>
    <div>
        404
    </div>
</template>

<script>
    export default {
        data() {
            return {};
        },
        created() {

        },
        mounted() {

        },
        watch: {},
        methods: {},
        computed: {},
        components: {}
    };
</script>

<style scoped>

</style>