

const app = {
    state: {

    },
    getters:{

    },
    mutations: {

    }
};

export default app;
