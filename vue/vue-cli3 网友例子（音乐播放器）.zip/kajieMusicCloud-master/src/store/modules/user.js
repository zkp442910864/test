
const user = {
    state: {

    },
    getters:{

    },
    mutations: {

    }
};

export default user;
