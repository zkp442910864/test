<template>
  <h1 class="title"><slot></slot></h1>
</template>

<style lang="less" scoped>
@import './title.less';
</style>
