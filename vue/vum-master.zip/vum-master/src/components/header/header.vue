<template>
  <nav class="nav">
    <slot></slot>
  </nav>
</template>

<script>
export default {
}
</script>

<style lang="less">
@import './header.less';
</style>
