<template>
  <nav class="nav-secondary">
    <slot></slot>
  </nav>
</template>

<script>
export default {
}
</script>

<style lang="less">
@import './second.less';
</style>
