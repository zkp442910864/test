import Modal from './Modal'
import Alert from './Alert'
import Confirm from './Confirm'
import Prompt from './Prompt'

export {
  Modal,
  Alert,
  Confirm,
  Prompt
}
