<template>
  <div class="action-button">
    <slot></slot>
  </div>
</template>
