<template>
  <div class="action-group">
    <slot></slot>
  </div>
</template>
