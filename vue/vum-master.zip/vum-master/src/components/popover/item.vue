<template>
  <div class="item"><slot></slot></div>
</template>

<style lang="less" scoped>
@import './item.less';
</style>
