import Wrapper from './wrapper'
import Slide from './slide'

const SlideWrapper = Wrapper
export {
  Slide,
  SlideWrapper
}
