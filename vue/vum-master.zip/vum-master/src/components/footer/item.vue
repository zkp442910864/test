<template>
  <a class="footer-item">
    <slot></slot>
  </a>
</template>
