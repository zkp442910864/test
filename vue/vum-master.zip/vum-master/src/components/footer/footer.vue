<template>
  <footer class="footer">
    <slot></slot>
  </footer>
</template>

<style lang="less">
@import "./footer.less";
</style>
