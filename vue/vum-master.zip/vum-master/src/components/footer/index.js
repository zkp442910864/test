import Footer from './footer'
import SecondFooter from './second'
import Item from './item'

const FooterItem = Item

export {
  Footer,
  SecondFooter,
  FooterItem,

  // for old version
  Item
}
