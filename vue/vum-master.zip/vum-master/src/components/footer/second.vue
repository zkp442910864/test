<template>
  <footer class="footer-secondary">
    <slot></slot>
  </footer>
</template>

<style lang="less">
@import "./second.less";
</style>
