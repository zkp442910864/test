<template>
  <div class="page"><slot></slot></div>
</template>
