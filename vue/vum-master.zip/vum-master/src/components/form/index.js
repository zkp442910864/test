import Form from './form'
import Item from './item'
import './form.less'

const FormItem = Item

export {
  Form,
  FormItem
}
