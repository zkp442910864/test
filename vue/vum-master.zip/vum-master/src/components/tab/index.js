import Tab from './Tab'
import TabItem from './TabItem'

export {
  Tab,
  TabItem
}
