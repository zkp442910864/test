import '@css/index.scss';
common.init();
console.log(123);
