
const HtmlWebpackPlugin = require('html-webpack-plugin'); // 处理html

const arr = [{
  entryKey: 'index',
  entry: './src/assets/js/index.ts',
  filename: 'index.html',
  template: './src/view/index.html',
}, {
  entryKey: 'test',
  entry: './src/assets/js/test.ts',
  filename: 'test.html',
  template: './src/view/test.html',
}];

/**
 * common  公共文件的名字
 */
const [common, template, entry] = ['common', [], {}];

arr.forEach((item) => {
  template.push(new HtmlWebpackPlugin({
    filename: item.filename,
    template: item.template,
    inject: true,
    hash: true,
    minify: {
      removeComments: true,
      collapseWhitespace: true,
    },
    chunks: [common, item.entryKey]
  }));

  entry[item.entryKey] = item.entry;
});


module.exports = { common, template, entry };