/* class MyObj {
  constructor (p) {
    this.p = p || '333';
  }

  get () {
    return this.p;
  }

  set (p) {
    this.p = p;
  }
}

class MyObj2 extends MyObj {
  constructor () {
    super('aaa');
  }
}

const m2 = new MyObj2();
console.log(m2.get());
 */