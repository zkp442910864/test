
// import require from 'require';

const num: number = 123;
const num2: number = 123;
const str: string = '123';
const o = {
  init(): void {
    console.log(1);
  }
};

o.init();

console.log(num + num2);
console.log(str);

class MyObj {
  public p: string;

  constructor(p: string) {
    // this.p = p || '333';
    this.set(p);
  }

  public get() {
    return this.p;
  }

  private set(p: string) {
    this.p = p;
  }
}

const mo = new MyObj('qqq');

console.log(mo.get());

// tslint:disable-next-line:label-position
// myThis: any = this;

// console.log(Promise.resolve('success'));
// module.hot;

const a = (): void => {
  console.log(11232);
  console.log(module['hot']);
};

if (module['hot']) {
  module['hot'].accept('./index.ts', () => {
    a();
    // const nextComponent = component();
    // document.body.replaceChild(nextComponent, demoComponent);
    // demoComponent = nextComponent;
  });
  module['hot'].dispose((data) => {
    console.log(data);
  });
}

// console.log(require('@img/top_bg.png'));

/* const p = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve('qweqwe');
  }, 1000);
});

p.then((val) => {
  console.log(val);
}); */
