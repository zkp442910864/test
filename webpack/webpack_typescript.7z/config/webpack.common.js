


const view = require('../view.js');
const webpack = require('webpack');
const path = require("path");
const MiniCssExtractPlugin = require('mini-css-extract-plugin'); // 提取公共的css
// const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin');

// console.log(path.resolve(__dirname, '..', 'src/view'));
const returnPath = (files, suffix) => {
  // 输出的资源文件路径
  if (files === 'js') {
    return `static/${files}/[name].js`;
  } else {
    return `static/${files}/[name].[hash:7].[ext]`;
  }
};

module.exports = {
  entry: view.entry,
  output: {
    path: path.resolve(__dirname, '..', 'dist'), // 输出的到文件夹下
    filename: returnPath('js', 'js'), // 文件的路径
    publicPath: '/' // html里的路径，可改成相对
  },
  module: {
    rules: [{
      test: /\.css$/,
      use: ['style-loader', 'css-loader']
    }, {
      test: /\.js$/,
      exclude: /(node_modules|bower_components)/,
      use: [{
        loader: 'babel-loader'
      }]
    }, {
      test: /\.(ts|tsx)$/,
      use: 'ts-loader',
      exclude: /node_modules/
    }, {
      test: /\.html$/,
      use: [{
        loader: 'html-loader',
        options: {
          attrs: ['img:src']
        }
      }]
    }, {
      test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
      use: [{
        loader: 'file-loader',
        options: {
          limit: 10000,
          name: returnPath('img')
        }
      }]
    },
    {
      test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
      use: [{
        loader: 'file-loader',
        options: {
          limit: 10000,
          name: returnPath('media')
        }
      }]
    },
    {
      test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
      use: [{
        loader: 'file-loader',
        options: {
          limit: 10000,
          name: returnPath('fonts')
        }
      }]
    }]
  },
  plugins: [
    ...view.template,
    new MiniCssExtractPlugin({
      filename: 'static/css/[name].css',
      chunkFilename: 'static/css/' + view.common + '.css'
    }),
    new webpack.ProvidePlugin({
      'Promise': 'bluebird'
    })
  ],
  optimization: {
    splitChunks: {
      cacheGroups: {
        commons: {
          name: view.common,
          chunks: 'initial',
          minChunks: view.template.length
        }
      }
    },
    minimize: true
  },
  resolve: {
    // extensions: ['.js', '.vue', '.json'],
    alias: {
      // 'vue$': 'vue/dist/vue.esm.js',
      '@view': path.resolve(__dirname, '..','src/view'),
      '@ts': path.resolve(__dirname, '..', 'src/assets/js'),
      '@img': path.resolve(__dirname, '..', 'src/assets/img'),
      '@css': path.resolve(__dirname, '..','src/assets/css'),
    }
  },
};